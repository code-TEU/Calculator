package com.example.calcut;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button[] btn = new Button[19];
    private double num1, num2, result;
    private String currentOutput = "";
    private String totalOutput = "";
    private TextView OUTPUT_TEXT;
    private TextView OUTPUT_TOTAL;

    private char sign;
    private int dotNum;
    private int plusNum;
    private int minNum;
    private int multNum;
    private int divNum;
    //private boolean num1


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //------------------------------------- DEFAULTS------
        OUTPUT_TEXT = (TextView) findViewById(R.id.output);
        OUTPUT_TOTAL = (TextView) findViewById(R.id.total);

        //initialized find view by ids
        initBtnView();

        //------------------------------------- BUTTONS LISTENER------

        //////ZERO BUTTON/////
        btn[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "0");
            }
        });

        //////1 BUTTON/////
        btn[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "1");
            }
        });

        //////2 BUTTON/////
        btn[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "2");
            }
        });

        //////3 BUTTON/////
        btn[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "3");
            }
        });

        //////4 BUTTON/////
        btn[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "4");
            }
        });

        //////5 BUTTON/////
        btn[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "5");
            }
        });

        //////6 BUTTON/////
        btn[6].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "6");
            }
        });

        //////7 BUTTON/////
        btn[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "7");
            }
        });

        //////8 BUTTON/////
        btn[8].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "8");
            }
        });

        //////9 BUTTON/////
        btn[9].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput += "9");
            }
        });

        //////DOT BUTTON/////
        btn[10].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                countCharacters();
                //print if there's no existing dot
                if (dotNum == 0){
                    OUTPUT_TEXT.setText(currentOutput += ".");
                }

                if (dotNum == 1) {
                    if (currentOutput.endsWith(".")) {
                    }
                    else if (!currentOutput.substring(currentOutput.indexOf(sign)+1 , currentOutput.length()).contains(".")){
                        OUTPUT_TEXT.setText(currentOutput += ".");
                    }
                }

            }
        });

        //////PLUS BUTTON/////
        btn[11].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countCharacters();

                //do nothing if + exist or its the first input
                if (plusNum == 1 || currentOutput == "") {
                }

                //replace if last is different sign
                else if (currentOutput.endsWith("-") ||
                        currentOutput.endsWith("*") ||
                        currentOutput.endsWith("/")) {
                    currentOutput = currentOutput.substring(0, currentOutput.length() - 1);
                    OUTPUT_TEXT.setText(currentOutput += "+");
                    sign = '+';
                }

                //print if there's no +
                else if (plusNum == 0) {
                    OUTPUT_TEXT.setText(currentOutput += "+");
                    sign = '+';
                }

            }


        });

        //////MINUS BUTTON/////
        btn[12].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countCharacters();
                //do nothing if + exist or its the first input
                if (!currentOutput.startsWith("-")) {
                    if (minNum<1){
                        OUTPUT_TEXT.setText(currentOutput += "-");
                        sign='-';
                    }
                    else {
                    }
                }

                else if (currentOutput.endsWith("-") || minNum==2){
                }

                //replace if last is different sign
                else if (   currentOutput.endsWith("+") ||
                            currentOutput.endsWith("*") ||
                            currentOutput.endsWith("/")) {
                    currentOutput = currentOutput.substring(0, currentOutput.length() - 1);
                    OUTPUT_TEXT.setText(currentOutput += "-");
                    sign = '-';
                }

                else if (currentOutput.startsWith("-") && !currentOutput.endsWith("-")) {
                        OUTPUT_TEXT.setText(currentOutput += "-");
                        sign='-';
                }

                else if (minNum==0) {
                    OUTPUT_TEXT.setText(currentOutput += "-");
                }



            }
        });

        //////MULTIPLY BUTTON/////
        btn[13].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput+="*");
                sign = '*';
            }
        });

        //////DIVIDE BUTTON/////
        btn[14].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OUTPUT_TEXT.setText(currentOutput+="/");
                sign = '/';
            }
        });

        //////EQUALS BUTTON/////
        btn[15].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countCharacters();

                if ( !countCharacters() ||
                        currentOutput.endsWith("+") || currentOutput.endsWith("-") ||
                        currentOutput.endsWith("*") || currentOutput.endsWith("/") ){
                }

                else if (plusNum==1 || minNum==1 || multNum==2 || divNum==1){
                    assignNumAndSign();
                    compute();
                }

                else if (!currentOutput.startsWith("-") && !checkLastIfSign() &&
                        plusNum==1 || minNum==1 || multNum==1 || divNum==1) {
                    assignNumAndSign();
                    compute();
                }

            }
        });

        /////% BUTTON/////
        btn[16].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countCharacters();
                //if there is no sign, convert to decimal
                if(!countCharacters()) {

                    currentOutput = String.valueOf(Double.parseDouble(currentOutput) / 100);
                    OUTPUT_TEXT.setText(currentOutput);
                }
                //do nothing if last is sign
                else if(countCharacters() && currentOutput.endsWith(String.valueOf(sign))) {
                }

                else if(countCharacters() && currentOutput.length()>currentOutput.indexOf(sign)) {
                    //convert second num
                    String secondNum = currentOutput.substring(currentOutput.indexOf(sign)+1, currentOutput.length());
                    String secondNumConverted = String.valueOf(Double.parseDouble(secondNum) / 100);

                    //remove second num (previous)
                    currentOutput = currentOutput.substring(0,currentOutput.indexOf(sign));
                    //concat second num (new)
                    OUTPUT_TEXT.setText(currentOutput+=sign+secondNumConverted);
                }
            }
        });

        /////AC BUTTON/////
        btn[17].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentOutput = "";
                OUTPUT_TEXT.setText("0");
                OUTPUT_TOTAL.setText("0");
                dotNum = 0;
                plusNum=0;
                minNum=0;
                multNum=0;
                divNum=0;
            }
        });

        /////DELETE BUTTON/////
        btn[18].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentOutput.length() == 0 || OUTPUT_TEXT.toString().length()==1) {
                    OUTPUT_TEXT.setText("0");
                } else {
                    currentOutput = currentOutput.substring(0, currentOutput.length() - 1);
                    OUTPUT_TEXT.setText(currentOutput);
                }
            }
        });


    }

    /////METHODS//////////METHODS//////////METHODS//////////METHODS//////////METHODS//////////METHODS/////


    /////INITIALIZE BUTTONS/////
    private void initBtnView() {
        btn[0] = (Button) findViewById(R.id.btn0);
        btn[1] = (Button) findViewById(R.id.btn1);
        btn[2] = (Button) findViewById(R.id.btn2);
        btn[3] = (Button) findViewById(R.id.btn3);
        btn[4] = (Button) findViewById(R.id.btn4);
        btn[5] = (Button) findViewById(R.id.btn5);
        btn[6] = (Button) findViewById(R.id.btn6);
        btn[7] = (Button) findViewById(R.id.btn7);
        btn[8] = (Button) findViewById(R.id.btn8);
        btn[9] = (Button) findViewById(R.id.btn9);
        btn[10] = (Button) findViewById(R.id.btnDot);
        btn[11] = (Button) findViewById(R.id.btnPlus);
        btn[12] = (Button) findViewById(R.id.btnMinus);
        btn[13] = (Button) findViewById(R.id.btnMult);
        btn[14] = (Button) findViewById(R.id.btnDiv);
        btn[15] = (Button) findViewById(R.id.btnEquals);
        btn[16] = (Button) findViewById(R.id.btnPercent);
        btn[17] = (Button) findViewById(R.id.btnAC);
        btn[18] = (Button) findViewById(R.id.btnDel);
    }


    /////COUNT SPECIFIC CHARACTERS ON SPECIFIC STRING/////
    private int countCharacter(String fromString, char countThisChar) {
        int count = 0;

        for (int x = 0; x < currentOutput.length(); x++) {
            //if char is == sign , count++
            if (fromString.charAt(x) == countThisChar) {
                count++;
            }
        }
        return count;
    }


    /////ASSIGN SIGN & NUM1 & NUM2////
    private void assignNumAndSign() {

        if (!currentOutput.startsWith("-")) {
            for (int i = 0; i < currentOutput.length(); i++) {
                if (currentOutput.indexOf("+") >= 1) {
                    sign = '+';
                } else if (currentOutput.indexOf("-") >= 1) {
                    sign = '-';
                } else if (currentOutput.indexOf("*") >= 1) {
                    sign = '*';
                } else if (currentOutput.indexOf("/") >= 1) {
                    sign = '/';
                }
            }

            num1 = Double.parseDouble(currentOutput.substring(0, currentOutput.indexOf(sign)));
            num2 = Double.parseDouble(currentOutput.substring(currentOutput.indexOf(sign) + 1, currentOutput.length()));
        }

        else if (currentOutput.startsWith("-")){
            for (int i = 1; i < currentOutput.length() ; i++) {
                if (currentOutput.indexOf("+") >= 1) {
                    sign = '+';
                } else if (currentOutput.indexOf("-") >= 1) {
                    sign = '-';
                } else if (currentOutput.indexOf("*") >= 1) {
                    sign = '*';
                } else if (currentOutput.indexOf("/") >= 1) {
                    sign = '/';
                }
            }
            num1 = Double.parseDouble(currentOutput.substring(0, currentOutput.indexOf(sign,1)));
            num2 = Double.parseDouble(currentOutput.substring(currentOutput.indexOf(sign, 1) + 1, currentOutput.length()));
        }
    }
        /*

        private void countCharacters();
        //if there is no sign, put in num1 (all)
        if (!countCharacters()) {
            num1 = Double.parseDouble(currentOutput.substring(0, currentOutput.length()));
        }
        //if there is any sign, put in num1 (0 to before sign)
        else if (countCharacters()) {
            num1 = Double.parseDouble(currentOutput.substring(0, currentOutput.indexOf(sign)));
        }
        //if there is any sign and length exceeds # of sign, put in num2 (after sign to last)
        else if (countCharacters() && currentOutput.length() > currentOutput.indexOf(Character.toString(sign))) {
            num2 = Double.parseDouble(currentOutput.substring(currentOutput.indexOf(sign) + 1, currentOutput.length()));
        }*/


    /////CHECK AFTER / SIGN IS ZERO/////
    private boolean checkZeroAfterDiv(){
        if (sign=='/' && num2/2==0){
            return true;
        }

        else{
            return false;
        }
    }

    //////CHECK IF THERE ARE SIGNS/////
    //COUNT EACH SIGN
    private boolean countCharacters(){
        dotNum = 0;
        plusNum = 0;
        minNum = 0;
        multNum = 0;
        divNum = 0;

        for (int x = 0; x < currentOutput.length(); x++) {
            //if char is == sign , count++
            if (currentOutput.charAt(x) == '+') {
                plusNum++;
            }
        }

        for (int x = 0; x < currentOutput.length(); x++) {
            //if char is == sign , count++
            if (currentOutput.charAt(x) == '-') {
                minNum++;
            }
        }

        for (int x = 0; x < currentOutput.length(); x++) {
            if (currentOutput.charAt(x) == '*') {
                multNum++;
            }
        }

        for (int x = 0; x < currentOutput.length(); x++) {
            if (currentOutput.charAt(x) == '/') {
                divNum++;
            }
        }

        for (int x = 0; x < currentOutput.length(); x++) {
            if (currentOutput.charAt(x) == '.') {
                dotNum++;
            }
        }

        if ((plusNum >= 1) || minNum >= 1 || multNum >= 1 || divNum >= 1) {
            return true;
        }
        else {
            return false;
        }

    }

    /////CHECK LAST IF SIGN////
    private boolean checkLastIfSign(){
        if (    currentOutput.endsWith("+") ||
                currentOutput.endsWith("-") ||
                currentOutput.endsWith("*") ||
                currentOutput.endsWith("/") ){
            return true;
        } else{
            return false;
        }
    }

    /////COMPUTE////
    private void compute() {
        if (checkZeroAfterDiv()) {
            OUTPUT_TOTAL.setText("ERROR");
        }

        else {
            //do this if num1 is not null
            switch (sign) {
                case '+':
                    result = num1 + num2;
                    break;
                case '-':
                    result = num1 - num2;
                    break;
                case '*':
                    result = num1 * num2;
                    break;
                case '/':
                    result = num1 / num2;
                    break;
            }


            /////TEST TO PRINT DECIMAL OR WHOLE NUMBER /////
            //int to string
            if (Double.isInfinite(result)) {
                totalOutput = String.valueOf(result).substring(0,30);
            } else {
                totalOutput = String.valueOf(result);
            }

            //extract nums after .
            int decimalNum = Integer.parseInt(totalOutput.substring(totalOutput.indexOf(".") + 1, totalOutput.length()));

            //check if after decimal is more than 0, print as whole number/decimal accordingly
            if (decimalNum != 0) {
                OUTPUT_TOTAL.setText(totalOutput);
            } else {
                OUTPUT_TOTAL.setText(totalOutput.substring(0, totalOutput.length() - 2));
            }

            OUTPUT_TEXT.setText(currentOutput = OUTPUT_TOTAL.getText().toString());
        }
    }

}




/*
 * get num
 * get sign, assign sign
 * get 2nd num == auto compute
 *
 * if +-* asign num if / print cant divide by 0
 * if theres +-*>=1, && last is not a sign or ., assign num1 && num2
 *
 * */